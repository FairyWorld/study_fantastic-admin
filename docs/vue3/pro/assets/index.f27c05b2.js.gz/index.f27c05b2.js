
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i,u,g as b}from"./index.30c1a0d0.js";import{o as n,l as r,$ as l,Y as _,k as e,w as C,y as I,a1 as S,B as p,C as m,D as c,F as $,a2 as B,a3 as L,a4 as N,q as T,H as j}from"./vendor.e498156c.js";const D={class:"copyright"},R=["href"],V={key:1},E=l(" All Rights Reserved "),F={setup(g){const t=u();return(a,o)=>(n(),r("footer",D,[l(" Copyright \xA9 "+_(e(t).copyright.dates)+" ",1),e(t).copyright.website?(n(),r("a",{key:0,href:e(t).copyrightWebsite,target:"_blank",rel:"noopener"},_(e(t).copyright.company)+",",9,R)):(n(),r("span",V,_(e(t).copyright.company)+",",1)),E]))}};var W=i(F,[["__scopeId","data-v-ad932524"]]);const q={setup(g){const{proxy:t}=j(),a=C(),o=u(),y=I(()=>b()),f=S("generateI18nTitle");function h(s){t.$i18n.locale=s,o.setDefaultLang(s),a.meta.title&&o.setTitle(f(a.meta.i18n,a.meta.title))}return(s,z)=>{const v=p("el-dropdown-item"),x=p("el-dropdown-menu"),w=p("el-dropdown");return e(o).toolbar.enableI18n?(n(),m(w,{key:0,class:"language-container",size:"default",onCommand:h},{dropdown:c(()=>[$(x,null,{default:c(()=>[(n(!0),r(L,null,B(e(y),(d,k)=>(n(),m(v,{key:k,disabled:e(o).app.defaultLang===d.name,command:d.name},{default:c(()=>[l(_(d.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:c(()=>[N(s.$slots,"default",{},void 0,!0)]),_:3})):T("v-if",!0)}}};var Y=i(q,[["__scopeId","data-v-3d086d48"]]);export{Y as _,W as a};
