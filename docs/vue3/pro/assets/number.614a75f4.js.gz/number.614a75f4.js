
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{q as l,m as r,n as m}from"./index.a1178b85.js";import{h as p,q as n,w as t,l as d,o as f,i as b,t as g,u as h,y as a}from"./vendor.ee7254f0.js";var s={};const k=a("1"),B=a("1"),N={setup(v){const e=l();function c(){e.setNumber(e.number+1)}function u(){e.setNumber(e.number-1)}return(x,C)=>{const _=m,o=d("el-button"),i=r;return f(),p("div",null,[n(_,{title:"\u6570\u5B57\u6807\u8BB0",content:"\u642D\u914D Pinia \u53EF\u5B9E\u73B0\u52A8\u6001\u8BBE\u7F6E\u3002\u8BF7\u63A7\u5236\u6570\u5B57\u5C55\u793A\u957F\u5EA6\uFF0C\u907F\u514D\u5BFC\u822A\u6807\u8BB0\u8986\u76D6\u5BFC\u822A\u6807\u9898\uFF0C\u4E3A 0 \u65F6\u5219\u9690\u85CF"}),n(i,null,{default:t(()=>[b("div",null,"\u5F53\u524D badge \u503C\uFF1A"+g(h(e).number),1),n(o,{icon:"el-icon-plus",onClick:c},{default:t(()=>[k]),_:1}),n(o,{icon:"el-icon-minus",onClick:u},{default:t(()=>[B]),_:1})]),_:1})])}}};typeof s=="function"&&s(N);export{N as default};
