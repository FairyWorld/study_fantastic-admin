
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as f}from"./index.a4aa7a11.js";import{_ as g}from"./index.5d564d7a.js";import{_ as v}from"./index.e66802dc.js";import{l as d,F as t,A as o,D as _,aB as V,o as r,U as b,m as s,$ as a}from"./vendor.ddb44672.js";const x={data(){return{dialogVisible:!1}}},k=a("\u70B9\u51FB\u6253\u5F00 Dialog"),C=s("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),j=s("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),B={class:"dialog-footer"},D=a("\u53D6 \u6D88"),h=a("\u786E \u5B9A");function w(y,e,N,$,n,U){const p=g,l=_("el-button"),u=_("el-dialog"),c=f,m=V("drag");return r(),d("div",null,[t(p,{title:"\u53EF\u62D6\u52A8\u5BF9\u8BDD\u6846"}),t(c,null,{default:o(()=>[t(l,{type:"text",onClick:e[0]||(e[0]=i=>n.dialogVisible=!0)},{default:o(()=>[k]),_:1}),b((r(),d("div",null,[t(u,{modelValue:n.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=i=>n.dialogVisible=i),width:"30%"},{title:o(()=>[C]),footer:o(()=>[s("span",B,[t(l,{onClick:e[1]||(e[1]=i=>n.dialogVisible=!1)},{default:o(()=>[D]),_:1}),t(l,{type:"primary",onClick:e[2]||(e[2]=i=>n.dialogVisible=!1)},{default:o(()=>[h]),_:1})])]),default:o(()=>[j]),_:1},8,["modelValue"])])),[[m]])]),_:1})])}var q=v(x,[["render",w]]);export{q as default};
