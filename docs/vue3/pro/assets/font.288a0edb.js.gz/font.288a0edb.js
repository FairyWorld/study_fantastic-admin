
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,c as t,b as s,w as i,j as l,ad as n,ac as c,q as d,p as e,k as o,e as p}from"./index.87af0725.js";const r={},f=a=>(e("data-v-a8c2a518"),a=a(),o(),a),m=f((()=>p("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),u=f((()=>p("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),_=f((()=>p("p",{class:"digital-7"},"Fantastic-admin",-1))),g=f((()=>p("p",{class:"digital-7"},"1234567890,.",-1))),v=f((()=>p("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),b=f((()=>p("p",{class:"digital-7_mono"},"1234567890,.",-1)));"function"==typeof l&&l(r);var j=a(r,[["render",function(a,l){const e=n,o=c;return d(),t("div",null,[s(e,{title:"自定义字体"},{content:i((()=>[m,u])),_:1}),s(o,{title:"Digital 7"},{default:i((()=>[_,g])),_:1}),s(o,{title:"Digital 7（等宽）"},{default:i((()=>[v,b])),_:1})])}],["__scopeId","data-v-a8c2a518"]]);export{j as default};
