
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{q as i,m as r,n as p}from"./index.62acde6f.js";import{h as d,q as t,w as n,l as m,o as f,i as g,t as x,u as h,y as s}from"./vendor.ee7254f0.js";var a={};const k=s("\u5207\u6362"),B=s("\u6E05\u7A7A"),b={setup(v){const e=i();function c(){e.setText(e.text=="\u70ED\u95E8"?"\u4FC3\u9500":"\u70ED\u95E8")}function _(){e.setText()}return(C,y)=>{const l=p,o=m("el-button"),u=r;return f(),d("div",null,[t(l,{title:"\u6587\u5B57\u6807\u8BB0",content:"\u642D\u914D Pinia \u53EF\u5B9E\u73B0\u52A8\u6001\u8BBE\u7F6E\u3002\u8BF7\u63A7\u5236\u6587\u5B57\u5C55\u793A\u957F\u5EA6\uFF0C\u907F\u514D\u5BFC\u822A\u6807\u8BB0\u8986\u76D6\u5BFC\u822A\u6807\u9898"}),t(u,null,{default:n(()=>[g("div",null,"\u5F53\u524D badge \u503C\uFF1A'"+x(h(e).text)+"'",1),t(o,{onClick:c},{default:n(()=>[k]),_:1}),t(o,{onClick:_},{default:n(()=>[B]),_:1})]),_:1})])}}};typeof a=="function"&&a(b);export{b as default};
