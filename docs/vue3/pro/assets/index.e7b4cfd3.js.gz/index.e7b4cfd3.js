
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{n as _,m,b as d}from"./index.a1178b85.js";import p from"./index.d6b97f5d.js";import{g as v,r as o,q as l,y as n,l as u}from"./vendor.ee7254f0.js";const x="_test1_uueil_10",f="_a_uueil_13",E="_test2_uueil_19";var e={"example-icon":"_example-icon_uueil_6",test1:x,a:f,test2:E},C=v({name:"JsxExample",render(){const i=o(["sidebar-jsx","sidebar-element"]).value.map(t=>l(d,{name:t,class:e["example-icon"]},null));let s=o(0);function a(t=1){s.value+=t}const r="<p>\u8FD9\u662F<i>\u4E00\u6BB5</i><b>HTML</b>\u4EE3\u7801</p>",c=l("p",null,[n("\u8FD9\u4E5F\u662F"),l("i",null,[n("\u4E00\u6BB5")]),l("b",null,[n("HTML")]),n("\u4EE3\u7801")]);return l("div",null,[l(_,{title:"JSX",content:"\u8BF7\u67E5\u770B\u672C\u9875\u9762\u6E90\u7801\uFF0C\u66F4\u591A JSX \u4ECB\u7ECD\u8BF7\u8BBF\u95EE\u5B98\u7F51\u6587\u6863\u3002"},null),l(m,null,{default:()=>[l("p",null,[n("\u8FD9\u662F\u4E24\u4E2A Svg Icon \u56FE\u6807")]),i,l(u("el-divider"),null,null),l("div",{class:e.test1},[l("div",{class:e.a},null)]),l("div",{class:e.test2},[l("div",{class:e.a},null)]),l(u("el-divider"),null,null),l(u("el-button"),{onClick:()=>a(10)},{default:()=>[n("\u70B9\u6211\uFF1A"),s.value]}),l("div",{innerHTML:r},null),c,l(u("el-divider"),null,null),l(p,null,null)]})])}});export{C as default};
