
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,c as t,b as s,w as i,j as l,ad as n,ac as d,q as e,p as c,k as o,e as p}from"./index.80ead521.js";const r={},m=a=>(c("data-v-a8c2a518"),a=a(),o(),a),u=m((()=>p("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),_=m((()=>p("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),f=m((()=>p("p",{class:"digital-7"},"Fantastic-admin",-1))),g=m((()=>p("p",{class:"digital-7"},"1234567890,.",-1))),v=m((()=>p("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),b=m((()=>p("p",{class:"digital-7_mono"},"1234567890,.",-1)));"function"==typeof l&&l(r);var j=a(r,[["render",function(a,l){const c=n,o=d;return e(),t("div",null,[s(c,{title:"自定义字体"},{content:i((()=>[u,_])),_:1}),s(o,{title:"Digital 7"},{default:i((()=>[f,g])),_:1}),s(o,{title:"Digital 7（等宽）"},{default:i((()=>[v,b])),_:1})])}],["__scopeId","data-v-a8c2a518"]]);export{j as default};
