
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{r as e,c as t,b as n,w as a,j as o,ad as r,n as i,ac as u,q as l,g as s,aa as c}from"./index.80ead521.js";function g(e){e.__i18n=e.__i18n||[],e.__i18n.push({locale:"",resource:{"zh-cn":{intro:e=>{const{normalize:t}=e;return t(["除了支持全局多语言切换，还支持 Vue 单文件模式语言切换，你可以尝试在这个页面点击右上角的语言切换试试"])}},"zh-tw":{intro:e=>{const{normalize:t}=e;return t(["除了支持全局多語言切換，還支持 Vue 單文件模式語言切換，你可以嘗試在這個頁面點擊右上角的語言切換試試"])}},en:{intro:e=>{const{normalize:t}=e;return t(["In addition to global multi-language switch, also support Vue single file mode language switch, you can try to click on the top right corner of the page to switch language"])}}}})}const p={setup(o){let g=e(1),p=e(100);function d(e){}function f(e){}return(e,o)=>{const h=r,z=i("el-pagination"),m=u;return l(),t("div",null,[n(h,{title:e.$t("route.feature.i18n"),content:e.$t("intro")},null,8,["title","content"]),n(m,{title:"Element 组件"},{default:a((()=>[n(z,{currentPage:s(g),"onUpdate:currentPage":o[0]||(o[0]=e=>c(g)?g.value=e:g=e),"page-size":s(p),"onUpdate:page-size":o[1]||(o[1]=e=>c(p)?p.value=e:p=e),"page-sizes":[100,200,300,400],layout:"total, sizes, prev, pager, next, jumper",total:400,onSizeChange:d,onCurrentChange:f},null,8,["currentPage","page-size"])])),_:1})])}}};"function"==typeof o&&o(p),g(p);export{p as default};
