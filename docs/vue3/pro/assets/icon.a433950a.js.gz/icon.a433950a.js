
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as b}from"./index.9853cb14.js";import{_ as g}from"./index.ac752417.js";import{_ as j}from"./index.cb82a5d1.js";import y from"./alert.40907eb4.js";import{l as c,F as e,A as n,D as o,o as s,k as t,aq as k,a3 as E,a2 as I,$,R as A}from"./vendor.c6c27760.js";import{h as i}from"./index.0dc2fa6b.js";import{_ as B}from"./index.1c697a52.js";const C=$(" \u641C\u7D22 "),F={setup(N){const r=Object.keys(A);return(V,q)=>{const p=j,m=o("el-icon-edit"),_=o("el-icon"),d=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),a=g,x=b,h=o("el-tooltip");return s(),c("div",null,[e(y),e(p,{title:"\u56FE\u6807"}),e(a,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(k)},{default:n(()=>[C]),_:1},8,["icon"])]),_:1}),e(a,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(s(!0),c(E,null,I(t(r),(l,v)=>(s(),c("div",{key:v,class:"list-icon"},[e(h,{class:"item",effect:"dark",content:t(i)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(x,{name:t(i)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var G=B(F,[["__scopeId","data-v-1ebb0afe"]]);export{G as default};
