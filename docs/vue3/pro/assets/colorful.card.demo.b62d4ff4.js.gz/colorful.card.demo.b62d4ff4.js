
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as d}from"./index.79435851.js";import{_ as l}from"./index.333bce41.js";import{_ as m}from"./index.df774eaa.js";import{_ as f}from"./index.30c1a0d0.js";import{B as c,l as i,F as o,D as e,o as p}from"./vendor.e498156c.js";import"./index.3b1c80c2.js";const s={};function u(x,g){const r=m,n=l,t=c("el-col"),_=c("el-row"),a=d;return p(),i("div",null,[o(r,{title:"\u591A\u5F69\u6E10\u53D8\u5361\u7247",content:"ColorfulCard"}),o(a,null,{default:e(()=>[o(_,{gutter:20},{default:e(()=>[o(t,{md:6},{default:e(()=>[o(n,{header:"\u5F00\u53D1\u6587\u6863",num:123,tip:"\u8F83\u4E0A\u5468\u4E0A\u534750%",icon:"index-document"})]),_:1}),o(t,{md:6},{default:e(()=>[o(n,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"\u57FA\u7840\u7EC4\u4EF6",num:12323,tip:"\u8F83\u4E0A\u5468\u4E0A\u534750%",icon:"index-component"})]),_:1}),o(t,{md:6},{default:e(()=>[o(n,{"color-from":"#ff763b","color-to":"#ffc480",header:"\u6269\u5C55\u7EC4\u4EF6",num:123,tip:"\u8F83\u4E0A\u5468\u4E0A\u534750%",icon:"index-component"})]),_:1}),o(t,{md:6},{default:e(()=>[o(n,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"\u4E1A\u52A1\u5E94\u7528\u9875\u9762",num:123,tip:"\u8F83\u4E0A\u5468\u4E0A\u534750%",icon:"index-page"})]),_:1})]),_:1})]),_:1})])}var B=f(s,[["render",u]]);export{B as default};
