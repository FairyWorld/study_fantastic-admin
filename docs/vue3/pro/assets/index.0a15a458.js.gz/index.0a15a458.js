
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{d as a,l as e,u as s,D as n,E as t,F as l,n as o,g as d,q as i,h as m,w as r,b as u,c,G as f,z as p,t as b,H as g,I as w,i as I,C as _}from"./index.80ead521.js";const x=a({name:"I18nSelector"}),y=Object.assign(x,{setup(a){const{proxy:x}=_(),y=e(),j=s(),k=n((()=>t())),z=l("generateI18nTitle");function C(a){x.$i18n.locale=a,j.setDefaultLang(a),y.meta.title&&j.setTitle(z(y.meta.i18n,y.meta.title),!1)}return(a,e)=>{const s=o("el-dropdown-item"),n=o("el-dropdown-menu"),t=o("el-dropdown");return d(j).toolbar.enableI18n?(i(),m(t,{key:0,class:"language-container",size:"default",onCommand:C},{dropdown:r((()=>[u(n,null,{default:r((()=>[(i(!0),c(g,null,f(d(k),((a,e)=>(i(),m(s,{key:e,disabled:d(j).app.defaultLang===a.name,command:a.name},{default:r((()=>[p(b(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:r((()=>[w(a.$slots,"default")])),_:3})):I("v-if",!0)}}});export{y as _};
