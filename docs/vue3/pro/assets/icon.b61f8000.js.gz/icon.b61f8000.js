
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,c as e,b as t,w as l,j as s,n,ac as o,q as c,g as d,ak as i,H as u,G as f,z as r,as as m,ad as p,B as _}from"./index.80ead521.js";import b from"./alert.8f6db08a.js";import{h as j}from"./index.0dc2fa6b.js";const y=r(" 搜索 "),k={setup(a){const s=Object.keys(m);return(a,r)=>{const m=p,k=n("el-icon-edit"),v=n("el-icon"),x=n("el-icon-share"),I=n("el-icon-delete"),h=n("el-button"),E=o,$=_,g=n("el-tooltip");return c(),e("div",null,[t(b),t(m,{title:"图标"}),t(E,{class:"demo"},{default:l((()=>[t(v,null,{default:l((()=>[t(k)])),_:1}),t(v,null,{default:l((()=>[t(x)])),_:1}),t(v,null,{default:l((()=>[t(I)])),_:1}),t(h,{type:"primary",icon:d(i)},{default:l((()=>[y])),_:1},8,["icon"])])),_:1}),t(E,{title:"图标集合"},{default:l((()=>[(c(!0),e(u,null,f(d(s),((a,s)=>(c(),e("div",{key:s,class:"list-icon"},[t(g,{class:"item",effect:"dark",content:d(j)(`ElIcon${a}`),placement:"top"},{default:l((()=>[t($,{name:d(j)(`ElIcon${a}`)},null,8,["name"])])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof s&&s(k);var v=a(k,[["__scopeId","data-v-cc12e516"]]);export{v as default};
