
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as v,u,g as x}from"./index.8f12b84b.js";import{j as m,o,l as c,$ as i,Y as _,k as e,B as S,w as I,a1 as $,D as d,z as p,A as r,F as j,a2 as B,a3 as L,a4 as N,q as T,H as D}from"./vendor.d1c84aa2.js";const R={class:"copyright"},V=["href"],z={key:1},A=i(" All Rights Reserved "),E=m({name:"Copyright"}),F=Object.assign(E,{setup(g){const t=u();return(a,n)=>(o(),c("footer",R,[i(" Copyright \xA9 "+_(e(t).copyright.dates)+" ",1),e(t).copyright.website?(o(),c("a",{key:0,href:e(t).copyright.website,target:"_blank",rel:"noopener"},_(e(t).copyright.company)+",",9,V)):(o(),c("span",z,_(e(t).copyright.company)+",",1)),A]))}});var G=v(F,[["__scopeId","data-v-93ffeb56"]]);const O=m({name:"I18nSelector"}),J=Object.assign(O,{setup(g){const{proxy:t}=D(),a=S(),n=u(),f=I(()=>x()),h=$("generateI18nTitle");function y(s){t.$i18n.locale=s,n.setDefaultLang(s),a.meta.title&&n.setTitle(h(a.meta.i18n,a.meta.title))}return(s,q)=>{const b=d("el-dropdown-item"),w=d("el-dropdown-menu"),k=d("el-dropdown");return e(n).toolbar.enableI18n?(o(),p(k,{key:0,class:"language-container",size:"default",onCommand:y},{dropdown:r(()=>[j(w,null,{default:r(()=>[(o(!0),c(L,null,B(e(f),(l,C)=>(o(),p(b,{key:C,disabled:e(n).app.defaultLang===l.name,command:l.name},{default:r(()=>[i(_(l.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:r(()=>[N(s.$slots,"default")]),_:3})):T("v-if",!0)}}});export{J as _,G as a};
