
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as m}from"./index.a91da01e.js";import{_}from"./index.454d22a3.js";import{_ as p}from"./index.d8082f89.js";import d from"./index.e20550e0.js";import{j as v,r as o,F as l,$ as e,D as u}from"./vendor.d1c84aa2.js";import"./index.8f12b84b.js";const f="_test1_uueil_10",x="_a_uueil_13",F="_test2_uueil_19";var n={"example-icon":"_example-icon_uueil_6",test1:f,a:x,test2:F},B=v({name:"JsxExample",render(){const i=o(["sidebar-jsx","sidebar-element"]).value.map(t=>l(p,{name:t,class:n["example-icon"]},null));let s=o(0);function a(t=1){s.value+=t}const r="<p>\u8FD9\u662F<i>\u4E00\u6BB5</i><b>HTML</b>\u4EE3\u7801</p>",c=l("p",null,[e("\u8FD9\u4E5F\u662F"),l("i",null,[e("\u4E00\u6BB5")]),l("b",null,[e("HTML")]),e("\u4EE3\u7801")]);return l("div",null,[l(_,{title:"JSX",content:"\u8BF7\u67E5\u770B\u672C\u9875\u9762\u6E90\u7801\uFF0C\u66F4\u591A JSX \u4ECB\u7ECD\u8BF7\u8BBF\u95EE\u5B98\u7F51\u6587\u6863\u3002"},null),l(m,null,{default:()=>[l("p",null,[e("\u8FD9\u662F\u4E24\u4E2A Svg Icon \u56FE\u6807")]),i,l(u("el-divider"),null,null),l("div",{class:n.test1},[l("div",{class:n.a},null)]),l("div",{class:n.test2},[l("div",{class:n.a},null)]),l(u("el-divider"),null,null),l(u("el-button"),{onClick:()=>a(10)},{default:()=>[e("\u70B9\u6211\uFF1A"),s.value]}),l("div",{innerHTML:r},null),c,l(u("el-divider"),null,null),l(d,null,null)]})])}});export{B as default};
