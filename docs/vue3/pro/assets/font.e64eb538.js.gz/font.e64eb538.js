
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,b as t,o as s,n as i}from"./index.2c18650f.js";import{h as n,q as l,w as o,o as e,p as d,k as c,i as f}from"./vendor.9da56f98.js";const p={},r=a=>(d("data-v-3f528ece"),a=a(),c(),a),m=r((()=>f("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),u=r((()=>f("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),_=r((()=>f("p",{class:"digital-7"},"Fantastic-admin",-1))),g=r((()=>f("p",{class:"digital-7"},"1234567890,.",-1))),v=r((()=>f("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),b=r((()=>f("p",{class:"digital-7_mono"},"1234567890,.",-1)));"function"==typeof t&&t(p);var j=a(p,[["render",function(a,t){const d=s,c=i;return e(),n("div",null,[l(d,{title:"自定义字体"},{content:o((()=>[m,u])),_:1}),l(c,{title:"Digital 7"},{default:o((()=>[_,g])),_:1}),l(c,{title:"Digital 7（等宽）"},{default:o((()=>[v,b])),_:1})])}],["__scopeId","data-v-3f528ece"]]);export{j as default};
