
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as g}from"./index.3b1c80c2.js";import{_ as j}from"./index.79435851.js";import{_ as y}from"./index.df774eaa.js";import k from"./alert.dde70af5.js";import{B as o,l as c,F as e,D as n,o as s,k as t,aq as b,a3 as E,a2 as I,$,R as B}from"./vendor.e498156c.js";import{h as i}from"./index.0dc2fa6b.js";import{_ as C}from"./index.30c1a0d0.js";const F=$(" \u641C\u7D22 "),N={setup(V){const r=Object.keys(B);return(q,w)=>{const p=y,m=o("el-icon-edit"),_=o("el-icon"),d=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),a=j,x=g,h=o("el-tooltip");return s(),c("div",null,[e(k),e(p,{title:"\u56FE\u6807"}),e(a,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(b)},{default:n(()=>[F]),_:1},8,["icon"])]),_:1}),e(a,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(s(!0),c(E,null,I(t(r),(l,v)=>(s(),c("div",{key:v,class:"list-icon"},[e(h,{class:"item",effect:"dark",content:t(i)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(x,{name:t(i)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var G=C(N,[["__scopeId","data-v-58969013"]]);export{G as default};
