
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,c as t,b as s,w as i,j as e,ad as l,ac as n,q as d,p as c,k as o,e as p}from"./index.afdde410.js";const f={},r=a=>(c("data-v-3f528ece"),a=a(),o(),a),m=r((()=>p("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),u=r((()=>p("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),_=r((()=>p("p",{class:"digital-7"},"Fantastic-admin",-1))),g=r((()=>p("p",{class:"digital-7"},"1234567890,.",-1))),v=r((()=>p("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),b=r((()=>p("p",{class:"digital-7_mono"},"1234567890,.",-1)));"function"==typeof e&&e(f);var j=a(f,[["render",function(a,e){const c=l,o=n;return d(),t("div",null,[s(c,{title:"自定义字体"},{content:i((()=>[m,u])),_:1}),s(o,{title:"Digital 7"},{default:i((()=>[_,g])),_:1}),s(o,{title:"Digital 7（等宽）"},{default:i((()=>[v,b])),_:1})])}],["__scopeId","data-v-3f528ece"]]);export{j as default};
