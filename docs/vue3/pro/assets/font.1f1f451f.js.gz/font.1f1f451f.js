
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as p,n as d,m as l}from"./index.a1178b85.js";import{h as r,q as a,w as _,o as m,p as u,k as f,i as t}from"./vendor.ee7254f0.js";var n={};const c={},o=e=>(u("data-v-a8c2a518"),e=e(),f(),e),g=o(()=>t("p",null,"\u81EA\u5B9A\u4E49\u5B57\u4F53\u9700\u8981\u4E0B\u8F7D\u5B57\u4F53\u6587\u4EF6\uFF0C\u4E0D\u5EFA\u8BAE\u5728\u975E\u82F1\u6587\u73AF\u5883\u4E2D\u4F7F\u7528",-1)),h=o(()=>t("p",{style:{"margin-bottom":"0"}},"\u4EE5\u4E0B\u4E3A\u6846\u67B6\u9884\u8BBE\u5B57\u4F53",-1)),v=o(()=>t("p",{class:"digital-7"},"Fantastic-admin",-1)),x=o(()=>t("p",{class:"digital-7"},"1234567890,.",-1)),k=o(()=>t("p",{class:"digital-7_mono"},"Fantastic-admin",-1)),y=o(()=>t("p",{class:"digital-7_mono"},"1234567890,.",-1));function I(e,w){const i=d,s=l;return m(),r("div",null,[a(i,{title:"\u81EA\u5B9A\u4E49\u5B57\u4F53"},{content:_(()=>[g,h]),_:1}),a(s,{title:"Digital 7"},{default:_(()=>[v,x]),_:1}),a(s,{title:"Digital 7\uFF08\u7B49\u5BBD\uFF09"},{default:_(()=>[k,y]),_:1})])}typeof n=="function"&&n(c);var b=p(c,[["render",I],["__scopeId","data-v-a8c2a518"]]);export{b as default};
