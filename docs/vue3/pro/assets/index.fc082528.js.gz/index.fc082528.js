
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as p,u,g as k}from"./index.6da96519.js";import{o as n,k as r,a0 as d,Z as _,u as e,t as w,x as I,a2 as S,A as i,B as m,C as c,D as B,a3 as D,a4 as L,a5 as N,m as T,G as $}from"./vendor.ab59999c.js";const j={class:"copyright"},R=["href"],V={key:1},A=d(" All Rights Reserved "),E={setup(g){const t=u();return(a,o)=>(n(),r("footer",j,[d(" Copyright \xA9 "+_(e(t).copyrightDates)+" ",1),e(t).copyrightWebsite?(n(),r("a",{key:0,href:e(t).copyrightWebsite,target:"_blank",rel:"noopener"},_(e(t).copyrightCompany)+",",9,R)):(n(),r("span",V,_(e(t).copyrightCompany)+",",1)),A]))}};var Z=p(E,[["__scopeId","data-v-482c0b3e"]]);const W={setup(g){const{proxy:t}=$(),a=w(),o=u(),f=I(()=>k()),y=S("generateI18nTitle");function h(s){t.$i18n.locale=s,o.setDefaultLang(s),a.meta.title&&o.setTitle(y(a.meta.i18n,a.meta.title))}return(s,z)=>{const v=i("el-dropdown-item"),x=i("el-dropdown-menu"),C=i("el-dropdown");return e(o).enableI18n?(n(),m(C,{key:0,class:"language-container",size:"default",onCommand:h},{dropdown:c(()=>[B(x,null,{default:c(()=>[(n(!0),r(L,null,D(e(f),(l,b)=>(n(),m(v,{key:b,disabled:e(o).defaultLang===l.name,command:l.name},{default:c(()=>[d(_(l.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:c(()=>[N(s.$slots,"default",{},void 0,!0)]),_:3})):T("v-if",!0)}}};var q=p(W,[["__scopeId","data-v-26355fa2"]]);export{q as _,Z as a};
