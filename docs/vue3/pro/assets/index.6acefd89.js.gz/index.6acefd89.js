
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as d}from"./index.4f3f72f3.js";import{_ as m}from"./index.80fc21c6.js";import{_}from"./index.d8082210.js";import p from"./index.c4fef2d9.js";import{j as f,r as i,F as e,$ as l,D as u}from"./vendor.7ef8ea63.js";import"./index.c053a834.js";const v="_test1_uueil_10",x="_a_uueil_13",F="_test2_uueil_19";var n={"example-icon":"_example-icon_uueil_6",test1:v,a:x,test2:F},T=f({name:"JsxExample",render(){const o=i(["sidebar-jsx","sidebar-element"]).value.map(t=>e(_,{name:t,class:n["example-icon"]},null));let s=i(0);function a(t=1){s.value+=t}const r="<p>\u8FD9\u662F<i>\u4E00\u6BB5</i><b>HTML</b>\u4EE3\u7801</p>",c=e("p",null,[l("\u8FD9\u4E5F\u662F"),e("i",null,[l("\u4E00\u6BB5")]),e("b",null,[l("HTML")]),l("\u4EE3\u7801")]);return e("div",null,[e(m,{title:"JSX",content:"\u8BF7\u67E5\u770B\u672C\u9875\u9762\u6E90\u7801\uFF0C\u66F4\u591A JSX \u4ECB\u7ECD\u8BF7\u8BBF\u95EE\u5B98\u7F51\u6587\u6863\u3002"},null),e(d,null,{default:()=>[e("p",null,[l("\u8FD9\u662F\u4E24\u4E2A Svg Icon \u56FE\u6807")]),o,e(u("el-divider"),null,null),e("div",{class:n.test1},[e("div",{class:n.a},null)]),e("div",{class:n.test2},[e("div",{class:n.a},null)]),e(u("el-divider"),null,null),e(u("el-button"),{onClick:()=>a(10)},{default:()=>[l("\u70B9\u6211\uFF1A"),s.value]}),e("div",{innerHTML:r},null),c,e(u("el-divider"),null,null),e(p,null,null)]})])}});export{T as default};
