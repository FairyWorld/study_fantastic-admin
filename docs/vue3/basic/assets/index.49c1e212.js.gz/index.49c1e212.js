
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./logo.96f1da49.js";import{_ as s,u as e}from"./index.d5f01412.js";import{i as o,j as t,a as l,b as r,e as n,u as i,q as d,r as u,f,k as c,l as p,t as m}from"./vendor.9748e354.js";const b=["src"],v={key:1},g=o({name:"Logo"});var h=s(Object.assign(g,{props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(s){const o=e(),g=t("Fantastic-admin 基础版"),h=t(a),j=l((()=>{let a={};return o.dashboard.enable&&(a.name="dashboard"),a}));return(a,e)=>{const t=u("router-link");return f(),r(t,{to:i(j),class:d(["title",{"is-link":i(o).dashboard.enable}]),title:g.value},{default:n((()=>[s.showLogo?(f(),c("img",{key:0,src:h.value,class:"logo"},null,8,b)):p("v-if",!0),s.showTitle?(f(),c("span",v,m(g.value),1)):p("v-if",!0)])),_:1},8,["to","class","title"])}}}),[["__scopeId","data-v-4b89d089"]]);export{h as default};
