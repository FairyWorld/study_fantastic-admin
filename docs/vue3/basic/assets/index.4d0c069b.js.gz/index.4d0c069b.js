
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.da9b58f1.js";import{_ as e,d as s,u as i,F as n,h as t,f as d,T as c,L as o,q as l,g as m,c as r,b as f,e as u,i as v,M as p,N as h,H as b,t as j}from"./index.b7fe7d7b.js";import k from"./index.e5b9fc40.js";import x from"./index.65bc0de9.js";import"./logo.96f1da49.js";const _={key:0},g={class:"header-container"},y={class:"main"},M={class:"nav"},C=["onClick"],H={key:1},q=s({name:"Header"});var w=e(Object.assign(q,{setup(e){const s=i(),q=n(),w=o("switchMenu");return(e,i)=>{const n=a;return l(),t(c,{name:"header"},{default:d((()=>["pc"===m(s).mode&&"head"===m(s).menu.menuMode?(l(),r("header",_,[f("div",g,[f("div",y,[u(k),v(" 顶部模式 "),f("div",M,[(l(!0),r(p,null,h(m(q).allMenus,((a,e)=>(l(),r(p,null,[a.children&&0!==a.children.length?(l(),r("div",{key:e,class:b(["item",{active:e==m(q).actived}]),onClick:a=>m(w)(e)},[a.meta.icon?(l(),t(n,{key:0,name:a.meta.icon},null,8,["name"])):v("v-if",!0),a.meta.title?(l(),r("span",H,j(a.meta.title),1)):v("v-if",!0)],10,C)):v("v-if",!0)],64)))),256))])]),u(x)])])):v("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-4ffa6d7c"]]);export{w as default};
