
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as p}from"./index.134061c0.js";import{i as v,b as _,e as f,Y as h,_ as g,f as e,u as s,k as a,s as r,g as l,l as n,F as d,x as k,q as y,t as C}from"./vendor.7c7b0e52.js";import S from"./index.1c753c42.js";import x from"./index.842fa201.js";import{_ as M,u as B,c as b}from"./index.78be6e19.js";import"./logo.96f1da49.js";const w={key:0},N={class:"header-container"},V={class:"main"},j={class:"nav"},F=["onClick"],H={key:1},L=v({name:"Header"}),T=Object.assign(L,{setup(q){const c=B(),i=b(),u=g("switchMenu");return(z,D)=>{const m=p;return e(),_(h,{name:"header"},{default:f(()=>[s(c).mode==="pc"&&s(c).menu.menuMode==="head"?(e(),a("header",w,[r("div",N,[r("div",V,[l(S),n(" \u9876\u90E8\u6A21\u5F0F "),r("div",j,[(e(!0),a(d,null,k(s(i).allMenus,(t,o)=>(e(),a(d,null,[t.children&&t.children.length!==0?(e(),a("div",{key:o,class:y(["item",{active:o==s(i).actived}]),onClick:E=>s(u)(o)},[t.meta.icon?(e(),_(m,{key:0,name:t.meta.icon},null,8,["name"])):n("v-if",!0),t.meta.title?(e(),a("span",H,C(t.meta.title),1)):n("v-if",!0)],10,F)):n("v-if",!0)],64))),256))])]),l(x)])])):n("v-if",!0)]),_:1})}}});var J=M(T,[["__scopeId","data-v-6a34b454"]]);export{J as default};
