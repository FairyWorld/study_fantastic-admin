
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,c as t,e as l,f as e,j as n,Z as s,n as u,q as d,y as f,b as i,$ as o}from"./index.b6307f63.js";import{_ as r}from"./logo.96f1da49.js";const m={},p=f(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),_=f(" 这里放页面内容 "),c=f(" 还可以结合 ElRow 使用 "),g=f(" 这里放页面内容 "),x=f(" 这里放页面内容 "),y=i("h1",null,"Fantastic-admin",-1),h=i("img",{src:r},null,-1),j=i("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);"function"==typeof n&&n(m);var b=a(m,[["render",function(a,n){const f=o,i=s,r=u("el-col"),m=u("el-row");return d(),t("div",null,[l(f,{title:"内容块",content:"PageMain"}),l(i,null,{default:e((()=>[p])),_:1}),l(i,{title:"你可以设置一个自定义的标题"},{default:e((()=>[_])),_:1}),l(m,{gutter:20,style:{margin:"-10px 10px"}},{default:e((()=>[l(r,{md:8},{default:e((()=>[l(i,{style:{margin:"10px 0"}},{default:e((()=>[c])),_:1})])),_:1}),l(r,{md:8},{default:e((()=>[l(i,{style:{margin:"10px 0"}},{default:e((()=>[g])),_:1})])),_:1}),l(r,{md:8},{default:e((()=>[l(i,{style:{margin:"10px 0"}},{default:e((()=>[x])),_:1})])),_:1})])),_:1}),l(i,{title:"带展开功能",collaspe:"",height:"200px"},{default:e((()=>[y,h,j])),_:1})])}]]);export{b as default};
