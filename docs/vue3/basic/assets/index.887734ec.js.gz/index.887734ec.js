
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.2247f9f8.js";import{i as e,b as s,e as i,Y as n,_ as t,f as d,u as o,k as r,s as m,g as l,l as c,F as f,x as u,q as v,t as p}from"./vendor.9748e354.js";import h from"./index.49c1e212.js";import j from"./index.69d3a774.js";import{_ as k,u as x,d as _}from"./index.d5f01412.js";import"./logo.96f1da49.js";const g={key:0},y={class:"header-container"},b={class:"main"},M={class:"nav"},C=["onClick"],q={key:1},w=e({name:"Header"});var F=k(Object.assign(w,{setup(e){const k=x(),w=_(),F=t("switchMenu");return(e,t)=>{const x=a;return d(),s(n,{name:"header"},{default:i((()=>["pc"===o(k).mode&&"head"===o(k).menu.menuMode?(d(),r("header",g,[m("div",y,[m("div",b,[l(h),c(" 顶部模式 "),m("div",M,[(d(!0),r(f,null,u(o(w).allMenus,((a,e)=>(d(),r(f,null,[a.children&&0!==a.children.length?(d(),r("div",{key:e,class:v(["item",{active:e==o(w).actived}]),onClick:a=>o(F)(e)},[a.meta.icon?(d(),s(x,{key:0,name:a.meta.icon},null,8,["name"])):c("v-if",!0),a.meta.title?(d(),r("span",q,p(a.meta.title),1)):c("v-if",!0)],10,C)):c("v-if",!0)],64)))),256))])]),l(j)])])):c("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-6a34b454"]]);export{F as default};
