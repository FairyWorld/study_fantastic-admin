
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,c as t,e,f as l,j as n,Z as s,n as u,q as d,y as i,b as f,$ as o}from"./index.9be238e7.js";import{_ as r}from"./logo.96f1da49.js";const m={},p=i(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),_=i(" 这里放页面内容 "),c=i(" 还可以结合 ElRow 使用 "),g=i(" 这里放页面内容 "),x=i(" 这里放页面内容 "),y=f("h1",null,"Fantastic-admin",-1),h=f("img",{src:r},null,-1),j=f("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);"function"==typeof n&&n(m);var b=a(m,[["render",function(a,n){const i=o,f=s,r=u("el-col"),m=u("el-row");return d(),t("div",null,[e(i,{title:"内容块",content:"PageMain"}),e(f,null,{default:l((()=>[p])),_:1}),e(f,{title:"你可以设置一个自定义的标题"},{default:l((()=>[_])),_:1}),e(m,{gutter:20,style:{margin:"-10px 10px"}},{default:l((()=>[e(r,{md:8},{default:l((()=>[e(f,{style:{margin:"10px 0"}},{default:l((()=>[c])),_:1})])),_:1}),e(r,{md:8},{default:l((()=>[e(f,{style:{margin:"10px 0"}},{default:l((()=>[g])),_:1})])),_:1}),e(r,{md:8},{default:l((()=>[e(f,{style:{margin:"10px 0"}},{default:l((()=>[x])),_:1})])),_:1})])),_:1}),e(f,{title:"带展开功能",collaspe:"",height:"200px"},{default:l((()=>[y,h,j])),_:1})])}]]);export{b as default};
