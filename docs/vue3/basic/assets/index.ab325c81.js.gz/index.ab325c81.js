
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{j as l,h as n}from"./index.d5f01412.js";import{_ as e}from"./index.2247f9f8.js";import a from"./index.146c96a1.js";import{i,j as s,g as u,v as r,r as t}from"./vendor.9748e354.js";var d="_example-icon_1rawi_12",o="_test1_1rawi_16",v="_a_1rawi_19",m="_test2_1rawi_25",c=i({name:"JsxExample",render(){const i=s(["sidebar-jsx","sidebar-element"]).value.map((l=>u(e,{name:l,class:d},null)));let c=s(0);const _=u("p",null,[r("这也是"),u("i",null,[r("一段")]),u("b",null,[r("HTML")]),r("代码")]);return u("div",null,[u(l,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),u(n,null,{default:()=>[u("p",null,[r("这是两个 Svg Icon 图标")]),i,u(t("el-divider"),null,null),u("div",{class:o},[u("div",{class:v},null)]),u("div",{class:m},[u("div",{class:v},null)]),u(t("el-divider"),null,null),u(t("el-button"),{onClick:()=>function(l=1){c.value+=l}(10)},{default:()=>[r("点我："),c.value]}),u("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),_,u(t("el-divider"),null,null),u(a,null,null)]})])}});export{c as default};
