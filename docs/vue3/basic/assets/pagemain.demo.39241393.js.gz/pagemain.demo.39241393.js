
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,b as t,h as e,j as l}from"./index.d5f01412.js";import{_ as s}from"./logo.96f1da49.js";import{k as n,g as d,e as r,r as f,f as i,v as o,s as u}from"./vendor.9748e354.js";const m={},p=o(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),_=o(" 这里放页面内容 "),g=o(" 还可以结合 ElRow 使用 "),c=o(" 这里放页面内容 "),x=o(" 这里放页面内容 "),y=u("h1",null,"Fantastic-admin",-1),h=u("img",{src:s},null,-1),j=u("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);"function"==typeof t&&t(m);var v=a(m,[["render",function(a,t){const s=l,o=e,u=f("el-col"),m=f("el-row");return i(),n("div",null,[d(s,{title:"内容块",content:"PageMain"}),d(o,null,{default:r((()=>[p])),_:1}),d(o,{title:"你可以设置一个自定义的标题"},{default:r((()=>[_])),_:1}),d(m,{gutter:20,style:{margin:"-10px 10px"}},{default:r((()=>[d(u,{md:8},{default:r((()=>[d(o,{style:{margin:"10px 0"}},{default:r((()=>[g])),_:1})])),_:1}),d(u,{md:8},{default:r((()=>[d(o,{style:{margin:"10px 0"}},{default:r((()=>[c])),_:1})])),_:1}),d(u,{md:8},{default:r((()=>[d(o,{style:{margin:"10px 0"}},{default:r((()=>[x])),_:1})])),_:1})])),_:1}),d(o,{title:"带展开功能",collaspe:"",height:"200px"},{default:r((()=>[y,h,j])),_:1})])}]]);export{v as default};
