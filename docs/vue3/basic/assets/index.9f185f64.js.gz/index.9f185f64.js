
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as d}from"./index.10df3ee5.js";import{_ as p}from"./index.f474927d.js";import{_}from"./index.b263c9e1.js";import m from"./index.1c608e88.js";import{A as v,F as o,g as e,Q as n,r as t}from"./vendor.8926ad61.js";import"./plugin-vue_export-helper.21dcd24c.js";const x="_test1_1rawi_16",f="_a_1rawi_19",F="_test2_1rawi_25";var l={"example-icon":"_example-icon_1rawi_12",test1:x,a:f,test2:F},J=v({name:"JsxExample",render(){const i=o(["sidebar-jsx","sidebar-element"]).value.map(s=>e(_,{name:s,class:l["example-icon"]},null));let u=o(0);function a(s=1){u.value+=s}const r="<p>\u8FD9\u662F<i>\u4E00\u6BB5</i><b>HTML</b>\u4EE3\u7801</p>",c=e("p",null,[n("\u8FD9\u4E5F\u662F"),e("i",null,[n("\u4E00\u6BB5")]),e("b",null,[n("HTML")]),n("\u4EE3\u7801")]);return e("div",null,[e(p,{title:"JSX",content:"\u8BF7\u67E5\u770B\u672C\u9875\u9762\u6E90\u7801\uFF0C\u66F4\u591A JSX \u4ECB\u7ECD\u8BF7\u8BBF\u95EE\u5B98\u7F51\u6587\u6863\u3002"},null),e(d,null,{default:()=>[e("p",null,[n("\u8FD9\u662F\u4E24\u4E2A Svg Icon \u56FE\u6807")]),i,e(t("el-divider"),null,null),e("div",{class:l.test1},[e("div",{class:l.a},null)]),e("div",{class:l.test2},[e("div",{class:l.a},null)]),e(t("el-divider"),null,null),e(t("el-button"),{onClick:()=>a(10)},{default:()=>[n("\u70B9\u6211\uFF1A"),u.value]}),e("div",{innerHTML:r},null),c,e(t("el-divider"),null,null),e(m,null,null)]})])}});export{J as default};
