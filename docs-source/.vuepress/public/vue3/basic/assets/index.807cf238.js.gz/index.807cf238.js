
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as d}from"./index.828ff984.js";import{i as p,b as c,e as f,Y as v,_ as g,f as t,u as s,k as n,g as h,l as a,s as l,F as _,x as k,q as b,t as M}from"./vendor.7c7b0e52.js";import S from"./index.e947030f.js";import{_ as y,u as C,c as x}from"./index.4bcd9cef.js";import"./logo.96f1da49.js";const w={key:0,class:"main-sidebar-container"},B={class:"nav"},N=["title","onClick"],V=p({name:"MainSidebar"}),j=Object.assign(V,{setup(F){const o=C(),r=x(),u=g("switchMenu");return(L,q)=>{const m=d;return t(),c(v,{name:"main-sidebar"},{default:f(()=>[s(o).menu.menuMode==="side"||s(o).mode==="mobile"&&s(o).menu.menuMode!=="single"?(t(),n("div",w,[h(S,{"show-title":!1,class:"sidebar-logo"}),a(" \u4FA7\u8FB9\u680F\u6A21\u5F0F\uFF08\u542B\u4E3B\u5BFC\u822A\uFF09 "),l("div",B,[(t(!0),n(_,null,k(s(r).allMenus,(e,i)=>(t(),n(_,null,[e.children&&e.children.length!==0?(t(),n("div",{key:i,class:b({item:!0,active:i===s(r).actived}),title:e.meta.title,onClick:z=>s(u)(i)},[e.meta.icon?(t(),c(m,{key:0,name:e.meta.icon},null,8,["name"])):a("v-if",!0),l("span",null,M(e.meta.title),1)],10,N)):a("v-if",!0)],64))),256))])])):a("v-if",!0)]),_:1})}}});var Y=y(j,[["__scopeId","data-v-e93e881c"]]);export{Y as default};
