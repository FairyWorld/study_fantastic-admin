
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as m}from"./index.5f2bc1a2.js";import{_}from"./index.ce04210c.js";import{_ as p}from"./index.693bf817.js";import d from"./index.1af0e181.js";import{A as v,F as o,g as l,Q as n,r as t}from"./vendor.a0579877.js";import"./plugin-vue_export-helper.21dcd24c.js";const f="_test1_1rawi_16",x="_a_1rawi_19",F="_test2_1rawi_25";var e={"example-icon":"_example-icon_1rawi_12",test1:f,a:x,test2:F},T=v({name:"JsxExample",render(){const a=o(["sidebar-jsx","sidebar-element"]).value.map(u=>l(p,{name:u,class:e["example-icon"]},null));let s=o(0);function i(u=1){s.value+=u}const r="<p>\u8FD9\u662F<i>\u4E00\u6BB5</i><b>HTML</b>\u4EE3\u7801</p>",c=l("p",null,[n("\u8FD9\u4E5F\u662F"),l("i",null,[n("\u4E00\u6BB5")]),l("b",null,[n("HTML")]),n("\u4EE3\u7801")]);return l("div",null,[l(_,{title:"JSX",content:"\u8BF7\u67E5\u770B\u672C\u9875\u9762\u6E90\u7801\uFF0C\u66F4\u591A JSX \u4ECB\u7ECD\u8BF7\u8BBF\u95EE\u5B98\u7F51\u6587\u6863\u3002"},null),l(m,null,{default:()=>[l("p",null,[n("\u8FD9\u662F\u4E24\u4E2A Svg Icon \u56FE\u6807")]),a,l(t("el-divider"),null,null),l("div",{class:e.test1},[l("div",{class:e.a},null)]),l("div",{class:e.test2},[l("div",{class:e.a},null)]),l(t("el-divider"),null,null),l(t("el-button"),{onClick:()=>i(10)},{default:()=>[n("\u70B9\u6211\uFF1A"),s.value]}),l("div",{innerHTML:r},null),c,l(t("el-divider"),null,null),l(d,null,null)]})])}});export{T as default};
