
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.8e17ce0a.js";import{_ as e,d as s,u as i,F as n,h as t,f as d,T as c,L as o,q as l,g as m,c as r,b as f,e as u,i as v,M as p,N as h,H as j,t as k}from"./index.fc479745.js";import x from"./index.036f9088.js";import _ from"./index.fe220f5b.js";import"./logo.96f1da49.js";const b={key:0},g={class:"header-container"},y={class:"main"},M={class:"nav"},C=["onClick"],H={key:1},q=s({name:"Header"});var w=e(Object.assign(q,{setup(e){const s=i(),q=n(),w=o("switchMenu");return(e,i)=>{const n=a;return l(),t(c,{name:"header"},{default:d((()=>["pc"===m(s).mode&&"head"===m(s).menu.menuMode?(l(),r("header",b,[f("div",g,[f("div",y,[u(x),v(" 顶部模式 "),f("div",M,[(l(!0),r(p,null,h(m(q).allMenus,((a,e)=>(l(),r(p,null,[a.children&&0!==a.children.length?(l(),r("div",{key:e,class:j(["item",{active:e==m(q).actived}]),onClick:a=>m(w)(e)},[a.meta.icon?(l(),t(n,{key:0,name:a.meta.icon},null,8,["name"])):v("v-if",!0),a.meta.title?(l(),r("span",H,k(a.meta.title),1)):v("v-if",!0)],10,C)):v("v-if",!0)],64)))),256))])]),u(_)])])):v("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-6a34b454"]]);export{w as default};
