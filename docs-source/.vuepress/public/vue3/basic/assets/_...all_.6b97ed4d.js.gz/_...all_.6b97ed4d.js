
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as d}from"./index.828ff984.js";import{j as i,a5 as p,o as v,k as f,g as n,s as o,e as m,y as h,z as y,R as I,r as g,f as k,v as w,t as x}from"./vendor.7c7b0e52.js";import{_ as b}from"./index.4bcd9cef.js";var s={};const _=t=>(h("data-v-45b4a4ec"),t=t(),y(),t),B={class:"notfound"},S={class:"content"},C=_(()=>o("h1",null,"404",-1)),N=_(()=>o("div",{class:"desc"},"\u62B1\u6B49\uFF0C\u4F60\u8BBF\u95EE\u7684\u9875\u9762\u4E0D\u5B58\u5728",-1)),c={setup(t){const r=I(),e=i({inter:null,countdown:5});p(()=>{clearInterval(e.value.inter)}),v(()=>{e.value.inter=setInterval(()=>{e.value.countdown--,e.value.countdown==0&&(clearInterval(e.value.inter),a())},1e3)});function a(){r.push("/")}return(R,V)=>{const l=d,u=g("el-button");return k(),f("div",B,[n(l,{name:"404"}),o("div",S,[C,N,n(u,{type:"primary",onClick:a},{default:m(()=>[w(x(e.value.countdown)+" \u79D2\u540E\uFF0C\u8FD4\u56DE\u9996\u9875",1)]),_:1})])])}}};typeof s=="function"&&s(c);var E=b(c,[["__scopeId","data-v-45b4a4ec"]]);export{E as default};
