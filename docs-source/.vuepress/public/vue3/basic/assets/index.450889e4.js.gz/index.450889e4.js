
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as e}from"./index.2247f9f8.js";import{i as a,b as s,e as i,Y as n,_ as t,f as l,u as o,k as d,g as m,l as r,s as c,F as u,x as f,q as v,t as p}from"./vendor.9748e354.js";import b from"./index.49c1e212.js";import{_ as g,u as j,d as k}from"./index.d5f01412.js";import"./logo.96f1da49.js";const _={key:0,class:"main-sidebar-container"},h={class:"nav"},x=["title","onClick"],M=a({name:"MainSidebar"});var y=g(Object.assign(M,{setup(a){const g=j(),M=k(),y=t("switchMenu");return(a,t)=>{const j=e;return l(),s(n,{name:"main-sidebar"},{default:i((()=>["side"===o(g).menu.menuMode||"mobile"===o(g).mode&&"single"!==o(g).menu.menuMode?(l(),d("div",_,[m(b,{"show-title":!1,class:"sidebar-logo"}),r(" 侧边栏模式（含主导航） "),c("div",h,[(l(!0),d(u,null,f(o(M).allMenus,((e,a)=>(l(),d(u,null,[e.children&&0!==e.children.length?(l(),d("div",{key:a,class:v({item:!0,active:a===o(M).actived}),title:e.meta.title,onClick:e=>o(y)(a)},[e.meta.icon?(l(),s(j,{key:0,name:e.meta.icon},null,8,["name"])):r("v-if",!0),c("span",null,p(e.meta.title),1)],10,x)):r("v-if",!0)],64)))),256))])])):r("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-448d696a"]]);export{y as default};
