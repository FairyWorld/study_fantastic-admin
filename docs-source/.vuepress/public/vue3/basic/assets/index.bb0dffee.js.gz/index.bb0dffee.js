
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{d as l,r as n,e,y as a,$ as i,Z as s,n as u}from"./index.9be238e7.js";import{_ as d}from"./index.b2b8566d.js";import r from"./index.74c2ff30.js";var t="_example-icon_1rawi_12",o="_test1_1rawi_16",v="_a_1rawi_19",c="_test2_1rawi_25",_=l({name:"JsxExample",render(){const l=n(["sidebar-jsx","sidebar-element"]).value.map((l=>e(d,{name:l,class:t},null)));let _=n(0);const m=e("p",null,[a("这也是"),e("i",null,[a("一段")]),e("b",null,[a("HTML")]),a("代码")]);return e("div",null,[e(i,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),e(s,null,{default:()=>[e("p",null,[a("这是两个 Svg Icon 图标")]),l,e(u("el-divider"),null,null),e("div",{class:o},[e("div",{class:v},null)]),e("div",{class:c},[e("div",{class:v},null)]),e(u("el-divider"),null,null),e(u("el-button"),{onClick:()=>function(l=1){_.value+=l}(10)},{default:()=>[a("点我："),_.value]}),e("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),m,e(u("el-divider"),null,null),e(r,null,null)]})])}});export{_ as default};
