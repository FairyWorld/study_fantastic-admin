
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a}from"./index.8e17ce0a.js";import{_ as e,d as s,u as i,F as n,h as t,f as l,T as o,L as d,q as m,g as c,c as r,e as u,i as f,b as v,M as p,N as b,H as g,t as h}from"./index.fc479745.js";import M from"./index.036f9088.js";import"./logo.96f1da49.js";const j={key:0,class:"main-sidebar-container"},k={class:"nav"},_=["title","onClick"],x=s({name:"MainSidebar"});var y=e(Object.assign(x,{setup(e){const s=i(),x=n(),y=d("switchMenu");return(e,i)=>{const n=a;return m(),t(o,{name:"main-sidebar"},{default:l((()=>["side"===c(s).menu.menuMode||"mobile"===c(s).mode&&"single"!==c(s).menu.menuMode?(m(),r("div",j,[u(M,{"show-title":!1,class:"sidebar-logo"}),f(" 侧边栏模式（含主导航） "),v("div",k,[(m(!0),r(p,null,b(c(x).allMenus,((a,e)=>(m(),r(p,null,[a.children&&0!==a.children.length?(m(),r("div",{key:e,class:g({item:!0,active:e===c(x).actived}),title:a.meta.title,onClick:a=>c(y)(e)},[a.meta.icon?(m(),t(n,{key:0,name:a.meta.icon},null,8,["name"])):f("v-if",!0),v("span",null,h(a.meta.title),1)],10,_)):f("v-if",!0)],64)))),256))])])):f("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-448d696a"]]);export{y as default};
