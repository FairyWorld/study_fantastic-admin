
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as e,b as a,n as t,o as l,c as s}from"./index.2c18650f.js";import n from"./alert.93d55ba6.js";import{h as o,q as c,w as i,l as d,o as r,u,ar as f,F as m,C as p,y as _,Z as b}from"./vendor.9da56f98.js";import{h as y}from"./index.0dc2fa6b.js";const j=_(" 搜索 "),v={setup(e){const a=Object.keys(b);return(e,_)=>{const b=l,v=d("el-icon-edit"),h=d("el-icon"),k=d("el-icon-share"),x=d("el-icon-delete"),I=d("el-button"),E=t,$=s,q=d("el-tooltip");return r(),o("div",null,[c(n),c(b,{title:"图标"}),c(E,{class:"demo"},{default:i((()=>[c(h,null,{default:i((()=>[c(v)])),_:1}),c(h,null,{default:i((()=>[c(k)])),_:1}),c(h,null,{default:i((()=>[c(x)])),_:1}),c(I,{type:"primary",icon:u(f)},{default:i((()=>[j])),_:1},8,["icon"])])),_:1}),c(E,{title:"图标集合"},{default:i((()=>[(r(!0),o(m,null,p(u(a),((e,a)=>(r(),o("div",{key:a,class:"list-icon"},[c(q,{class:"item",effect:"dark",content:u(y)(`ElIcon${e}`),placement:"top"},{default:i((()=>[c($,{name:u(y)(`ElIcon${e}`)},null,8,["name"])])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof a&&a(v);var h=e(v,[["__scopeId","data-v-2b6037a3"]]);export{h as default};
