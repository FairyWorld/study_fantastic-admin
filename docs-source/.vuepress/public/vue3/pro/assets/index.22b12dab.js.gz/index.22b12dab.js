
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as c}from"./index.9ed489d8.js";import{_ as l}from"./index.abc7a202.js";import{_ as r}from"./index.64e7900a.js";import{l as p,F as e,A as o,D as i,o as m,m as t,$ as d}from"./vendor.bcd7a662.js";const u={methods:{close(){this.$tabbar.close("/dashboard")}}},f=t("p",null,"\u8BBF\u95EE\u4FA7\u8FB9\u680F\u5BFC\u822A\u91CC\u7684\u4EFB\u610F\u8DEF\u7531\uFF0C\u90FD\u4F1A\u5728\u6807\u7B7E\u680F\u91CC\u81EA\u52A8\u521B\u5EFA\u4E00\u4E2A\u6807\u7B7E\u3002",-1),h=t("p",null,"\u9664\u4E86\u5728\u6807\u7B7E\u680F\u91CC\u64CD\u4F5C\u5173\u95ED\u6807\u7B7E\uFF0C\u4F60\u4E5F\u53EF\u4EE5\u4F7F\u7528\u5168\u5C40\u65B9\u6CD5\u5173\u95ED\u5F53\u524D\u9875\u9762\u7684\u6807\u7B7E\u3002\u4F46\u5982\u679C\u5F53\u524D\u53EA\u6709\u4E00\u4E2A\u6807\u7B7E\u65F6\uFF0C\u5219\u65E0\u6CD5\u5173\u95ED\u3002",-1),x=d("\u5173\u95ED\u5F53\u524D\u6807\u7B7E\u9875");function b($,g,k,C,v,n){const s=l,_=i("el-button"),a=c;return m(),p("div",null,[e(s,{title:"\u6807\u7B7E\u680F",content:"\u529F\u80FD\u7C7B\u4F3C\u4E8E\u6D4F\u89C8\u5668\u7684\u6807\u7B7E\u680F\uFF0C\u652F\u6301\u53F3\u952E\u64CD\u4F5C"}),e(a,null,{default:o(()=>[f,h,e(_,{onClick:n.close},{default:o(()=>[x]),_:1},8,["onClick"])]),_:1})])}var A=r(u,[["render",b]]);export{A as default};
