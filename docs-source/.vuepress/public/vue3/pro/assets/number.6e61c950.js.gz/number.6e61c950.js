
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as r}from"./index.a91da01e.js";import{_ as i}from"./index.454d22a3.js";import{n as l}from"./index.8f12b84b.js";import{l as m,F as n,A as o,D as p,o as d,m as f,Y as b,k as g,$ as s}from"./vendor.d1c84aa2.js";const h=s("1"),k=s("1"),D={setup(B){const e=l();function a(){e.setNumber(e.number+1)}function _(){e.setNumber(e.number-1)}return(N,x)=>{const c=i,t=p("el-button"),u=r;return d(),m("div",null,[n(c,{title:"\u6570\u5B57\u6807\u8BB0",content:"\u642D\u914D Pinia \u53EF\u5B9E\u73B0\u52A8\u6001\u8BBE\u7F6E\u3002\u8BF7\u63A7\u5236\u6570\u5B57\u5C55\u793A\u957F\u5EA6\uFF0C\u907F\u514D\u5BFC\u822A\u6807\u8BB0\u8986\u76D6\u5BFC\u822A\u6807\u9898\uFF0C\u4E3A 0 \u65F6\u5219\u9690\u85CF"}),n(u,null,{default:o(()=>[f("div",null,"\u5F53\u524D badge \u503C\uFF1A"+b(g(e).number),1),n(t,{icon:"el-icon-plus",onClick:a},{default:o(()=>[h]),_:1}),n(t,{icon:"el-icon-minus",onClick:_},{default:o(()=>[k]),_:1})]),_:1})])}}};export{D as default};
