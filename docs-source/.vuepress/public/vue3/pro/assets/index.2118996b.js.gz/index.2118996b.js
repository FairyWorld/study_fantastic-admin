
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i,u,g as b}from"./index.1c697a52.js";import{o as n,l as r,$ as d,Y as _,k as e,B as C,w as I,a1 as S,D as p,z as m,A as c,F as $,a2 as B,a3 as L,a4 as N,q as T,H as j}from"./vendor.c6c27760.js";const D={class:"copyright"},R=["href"],V={key:1},z=d(" All Rights Reserved "),A={setup(g){const t=u();return(a,o)=>(n(),r("footer",D,[d(" Copyright \xA9 "+_(e(t).copyright.dates)+" ",1),e(t).copyright.website?(n(),r("a",{key:0,href:e(t).copyright.website,target:"_blank",rel:"noopener"},_(e(t).copyright.company)+",",9,R)):(n(),r("span",V,_(e(t).copyright.company)+",",1)),z]))}};var Y=i(A,[["__scopeId","data-v-437d3efa"]]);const E={setup(g){const{proxy:t}=j(),a=C(),o=u(),f=I(()=>b()),y=S("generateI18nTitle");function h(s){t.$i18n.locale=s,o.setDefaultLang(s),a.meta.title&&o.setTitle(y(a.meta.i18n,a.meta.title))}return(s,F)=>{const v=p("el-dropdown-item"),w=p("el-dropdown-menu"),x=p("el-dropdown");return e(o).toolbar.enableI18n?(n(),m(x,{key:0,class:"language-container",size:"default",onCommand:h},{dropdown:c(()=>[$(w,null,{default:c(()=>[(n(!0),r(L,null,B(e(f),(l,k)=>(n(),m(v,{key:k,disabled:e(o).app.defaultLang===l.name,command:l.name},{default:c(()=>[d(_(l.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:c(()=>[N(s.$slots,"default",{},void 0,!0)]),_:3})):T("v-if",!0)}}};var G=i(E,[["__scopeId","data-v-4fed6462"]]);export{G as _,Y as a};
