
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,c as t,b as l,w as e,j as n,ac as s,n as d,q as u,z as i,e as f,ad as o}from"./index.87af0725.js";import{_ as r}from"./logo.96f1da49.js";const m={},p=i(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),_=i(" 这里放页面内容 "),c=i(" 还可以结合 ElRow 使用 "),g=i(" 这里放页面内容 "),x=i(" 这里放页面内容 "),y=f("h1",null,"Fantastic-admin",-1),h=f("img",{src:r},null,-1),j=f("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);"function"==typeof n&&n(m);var w=a(m,[["render",function(a,n){const i=o,f=s,r=d("el-col"),m=d("el-row");return u(),t("div",null,[l(i,{title:"内容块",content:"PageMain"}),l(f,null,{default:e((()=>[p])),_:1}),l(f,{title:"你可以设置一个自定义的标题"},{default:e((()=>[_])),_:1}),l(m,{gutter:20,style:{margin:"-10px 10px"}},{default:e((()=>[l(r,{md:8},{default:e((()=>[l(f,{style:{margin:"10px 0"}},{default:e((()=>[c])),_:1})])),_:1}),l(r,{md:8},{default:e((()=>[l(f,{style:{margin:"10px 0"}},{default:e((()=>[g])),_:1})])),_:1}),l(r,{md:8},{default:e((()=>[l(f,{style:{margin:"10px 0"}},{default:e((()=>[x])),_:1})])),_:1})])),_:1}),l(f,{title:"带展开功能",collaspe:"",height:"200px"},{default:e((()=>[y,h,j])),_:1})])}]]);export{w as default};
