
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as f}from"./index.79435851.js";import{_ as g}from"./index.df774eaa.js";import{_ as v}from"./index.30c1a0d0.js";import{B as d,aB as V,l as _,F as t,D as o,o as r,V as x,m as s,$ as a}from"./vendor.e498156c.js";const b={data(){return{dialogVisible:!1}}},k=a("\u70B9\u51FB\u6253\u5F00 Dialog"),B=s("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),C=s("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),j={class:"dialog-footer"},D=a("\u53D6 \u6D88"),$=a("\u786E \u5B9A");function h(w,e,y,N,n,E){const p=g,l=d("el-button"),u=d("el-dialog"),c=f,m=V("drag");return r(),_("div",null,[t(p,{title:"\u53EF\u62D6\u52A8\u5BF9\u8BDD\u6846"}),t(c,null,{default:o(()=>[t(l,{type:"text",onClick:e[0]||(e[0]=i=>n.dialogVisible=!0)},{default:o(()=>[k]),_:1}),x((r(),_("div",null,[t(u,{modelValue:n.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=i=>n.dialogVisible=i),width:"30%"},{title:o(()=>[B]),footer:o(()=>[s("span",j,[t(l,{onClick:e[1]||(e[1]=i=>n.dialogVisible=!1)},{default:o(()=>[D]),_:1}),t(l,{type:"primary",onClick:e[2]||(e[2]=i=>n.dialogVisible=!1)},{default:o(()=>[$]),_:1})])]),default:o(()=>[C]),_:1},8,["modelValue"])])),[[m]])]),_:1})])}var z=v(b,[["render",h]]);export{z as default};
