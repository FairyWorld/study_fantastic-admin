
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{u,m as r,n as m}from"./index.62acde6f.js";import{h as p,q as e,w as o,l as g,o as f,y as d,t as x,u as h,i as s,O as S}from"./vendor.ee7254f0.js";var a={};const k=s("p",null,"\u53EF\u901A\u8FC7\u53CC\u51FB\u6807\u7B7E\u9875\uFF0C\u6216\u5728\u6807\u7B7E\u9875\u4E0A\u53F3\u952E\u5E76\u9009\u62E9\u201C\u6700\u5927\u5316\u201D\u8FDB\u5165\u3002",-1),y=s("p",null,"\u540C\u65F6\u6846\u67B6\u8FD8\u63D0\u4F9B\u5168\u5C40\u51FD\u6570\uFF0C\u53EF\u81EA\u7531\u63A7\u5236\u4E3B\u9875\u9762\u662F\u5426\u6700\u5927\u5316\u3002",-1),z={setup(C){const{proxy:t}=S(),n=u();function i(){n.mainPageMaximizeStatus?t.$mainPageMaximize(!1):t.$mainPageMaximize(!0)}return(M,P)=>{const c=m,_=g("el-button"),l=r;return f(),p("div",null,[e(c,{title:"\u4E3B\u9875\u9762\u6700\u5927\u5316",content:"\u6269\u5927\u53EF\u89C6\u8303\u56F4\u548C\u64CD\u4F5C\u533A\u57DF\uFF0C\u80FD\u66F4\u4E13\u6CE8\u4E8E\u4E3B\u9875\u9762\u4E0A\u7684\u64CD\u4F5C"}),e(l,null,{default:o(()=>[k,y,e(_,{onClick:i},{default:o(()=>[d(x(h(n).mainPageMaximizeStatus?"\u9000\u51FA":"\u5F00\u542F")+"\u6700\u5927\u5316",1)]),_:1})]),_:1})])}}};typeof a=="function"&&a(z);export{z as default};
