
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as a,b as t,n as l,o as e}from"./index.2c18650f.js";import{_ as n}from"./logo.96f1da49.js";import{h as s,q as o,w as d,l as i,o as f,y as r,i as u}from"./vendor.9da56f98.js";const m={},p=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),_=r(" 这里放页面内容 "),c=r(" 还可以结合 ElRow 使用 "),g=r(" 这里放页面内容 "),x=r(" 这里放页面内容 "),y=u("h1",null,"Fantastic-admin",-1),h=u("img",{src:n},null,-1),j=u("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);"function"==typeof t&&t(m);var v=a(m,[["render",function(a,t){const n=e,r=l,u=i("el-col"),m=i("el-row");return f(),s("div",null,[o(n,{title:"内容块",content:"PageMain"}),o(r,null,{default:d((()=>[p])),_:1}),o(r,{title:"你可以设置一个自定义的标题"},{default:d((()=>[_])),_:1}),o(m,{gutter:20,style:{margin:"-10px 10px"}},{default:d((()=>[o(u,{md:8},{default:d((()=>[o(r,{style:{margin:"10px 0"}},{default:d((()=>[c])),_:1})])),_:1}),o(u,{md:8},{default:d((()=>[o(r,{style:{margin:"10px 0"}},{default:d((()=>[g])),_:1})])),_:1}),o(u,{md:8},{default:d((()=>[o(r,{style:{margin:"10px 0"}},{default:d((()=>[x])),_:1})])),_:1})])),_:1}),o(r,{title:"带展开功能",collaspe:"",height:"200px"},{default:d((()=>[y,h,j])),_:1})])}]]);export{v as default};
