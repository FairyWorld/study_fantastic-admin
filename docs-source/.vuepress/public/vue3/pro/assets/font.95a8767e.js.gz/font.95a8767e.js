
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i}from"./index.a4aa7a11.js";import{_ as c}from"./index.5d564d7a.js";import{_ as d}from"./index.e66802dc.js";import{l as p,F as a,A as _,o as l,s as r,t as m,m as t}from"./vendor.ddb44672.js";const u={},e=o=>(r("data-v-302b1ab8"),o=o(),m(),o),f=e(()=>t("p",null,"\u81EA\u5B9A\u4E49\u5B57\u4F53\u9700\u8981\u4E0B\u8F7D\u5B57\u4F53\u6587\u4EF6\uFF0C\u4E0D\u5EFA\u8BAE\u5728\u975E\u82F1\u6587\u73AF\u5883\u4E2D\u4F7F\u7528",-1)),g=e(()=>t("p",{style:{"margin-bottom":"0"}},"\u4EE5\u4E0B\u4E3A\u6846\u67B6\u9884\u8BBE\u5B57\u4F53",-1)),h=e(()=>t("p",{class:"digital-7"},"Fantastic-admin",-1)),v=e(()=>t("p",{class:"digital-7"},"1234567890,.",-1)),x=e(()=>t("p",{class:"digital-7_mono"},"Fantastic-admin",-1)),b=e(()=>t("p",{class:"digital-7_mono"},"1234567890,.",-1));function j(o,I){const n=c,s=i;return l(),p("div",null,[a(n,{title:"\u81EA\u5B9A\u4E49\u5B57\u4F53"},{content:_(()=>[f,g]),_:1}),a(s,{title:"Digital 7"},{default:_(()=>[h,v]),_:1}),a(s,{title:"Digital 7\uFF08\u7B49\u5BBD\uFF09"},{default:_(()=>[x,b]),_:1})])}var k=d(u,[["render",j],["__scopeId","data-v-302b1ab8"]]);export{k as default};
