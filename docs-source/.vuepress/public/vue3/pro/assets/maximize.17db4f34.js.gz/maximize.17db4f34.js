
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as r}from"./index.ac752417.js";import{_ as l}from"./index.cb82a5d1.js";import{u as m}from"./index.1c697a52.js";import{l as u,F as e,A as o,D as p,o as d,$ as g,Y as f,k as x,m as a,H as S}from"./vendor.c6c27760.js";const h=a("p",null,"\u53EF\u901A\u8FC7\u53CC\u51FB\u6807\u7B7E\u9875\uFF0C\u6216\u5728\u6807\u7B7E\u9875\u4E0A\u53F3\u952E\u5E76\u9009\u62E9\u201C\u6700\u5927\u5316\u201D\u8FDB\u5165\u3002",-1),j=a("p",null,"\u540C\u65F6\u6846\u67B6\u8FD8\u63D0\u4F9B\u5168\u5C40\u51FD\u6570\uFF0C\u53EF\u81EA\u7531\u63A7\u5236\u4E3B\u9875\u9762\u662F\u5426\u6700\u5927\u5316\u3002",-1),B={setup(k){const{proxy:t}=S(),n=m();function s(){n.mainPageMaximizeStatus?t.$mainPageMaximize(!1):t.$mainPageMaximize(!0)}return(z,C)=>{const i=l,c=p("el-button"),_=r;return d(),u("div",null,[e(i,{title:"\u4E3B\u9875\u9762\u6700\u5927\u5316",content:"\u6269\u5927\u53EF\u89C6\u8303\u56F4\u548C\u64CD\u4F5C\u533A\u57DF\uFF0C\u80FD\u66F4\u4E13\u6CE8\u4E8E\u4E3B\u9875\u9762\u4E0A\u7684\u64CD\u4F5C"}),e(_,null,{default:o(()=>[h,j,e(c,{onClick:s},{default:o(()=>[g(f(x(n).mainPageMaximizeStatus?"\u9000\u51FA":"\u5F00\u542F")+"\u6700\u5927\u5316",1)]),_:1})]),_:1})])}}};export{B as default};
