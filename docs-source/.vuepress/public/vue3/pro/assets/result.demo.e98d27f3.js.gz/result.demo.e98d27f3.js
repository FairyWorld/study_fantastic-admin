
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as r}from"./index.13c1af28.js";import{_ as l}from"./index.39221dba.js";import{_ as d}from"./index.a1ea47af.js";import{_ as i}from"./index.85d61d52.js";import{B as u,l as p,F as e,D as t,o as m,$ as o,m as _}from"./vendor.e498156c.js";const f={},x=o("\u8FD4\u56DE\u5217\u8868"),h=o("\u6253\u5370"),v=_("div",null,"\u60A8\u63D0\u4EA4\u7684\u5185\u5BB9\u6709\u5982\u4E0B\u9519\u8BEF\uFF1A",-1),y=_("div",null,[o(" \u60A8\u7684\u8D26\u6237\u5DF2\u88AB\u51BB\u7ED3 "),_("a",{href:"###"},"\u6253\u5370")],-1),g=o("\u8FD4\u56DE\u4FEE\u6539");function j(B,b){const c=d,n=u("el-button"),s=l,a=r;return m(),p("div",null,[e(c,{title:"\u5904\u7406\u7ED3\u679C",content:"Result"}),e(a,null,{default:t(()=>[e(s,{type:"success",title:"\u63D0\u4EA4\u6210\u529F",desc:"\u63D0\u4EA4\u7ED3\u679C\u9875\u7528\u4E8E\u53CD\u9988\u4E00\u7CFB\u5217\u64CD\u4F5C\u4EFB\u52A1\u7684\u5904\u7406\u7ED3\u679C\u3002"},{default:t(()=>[e(n,{type:"primary"},{default:t(()=>[x]),_:1}),e(n,null,{default:t(()=>[h]),_:1})]),_:1})]),_:1}),e(a,null,{default:t(()=>[e(s,{type:"error",title:"\u63D0\u4EA4\u5931\u8D25",desc:"\u7070\u8272\u989D\u5916\u533A\u57DF\u53EF\u4EE5\u663E\u793A\u4E00\u4E9B\u8865\u5145\u7684\u4FE1\u606F\u3002\u8BF7\u6838\u5BF9\u5E76\u4FEE\u6539\u4EE5\u4E0B\u4FE1\u606F\u540E\uFF0C\u518D\u91CD\u65B0\u63D0\u4EA4\u3002"},{extra:t(()=>[v,y]),default:t(()=>[e(n,{type:"primary"},{default:t(()=>[g]),_:1})]),_:1})]),_:1})])}var w=i(f,[["render",j]]);export{w as default};
