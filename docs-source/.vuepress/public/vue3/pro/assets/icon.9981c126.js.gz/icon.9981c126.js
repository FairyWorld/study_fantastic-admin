
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as g}from"./index.09189ae2.js";import{_ as j}from"./index.14df4c4d.js";import{_ as y}from"./index.245be67e.js";import k from"./alert.64c4acf8.js";import{l as c,F as e,A as n,D as o,o as s,k as t,aq as b,a3 as E,a2 as I,$,R as A}from"./vendor.7ef8ea63.js";import{h as i}from"./index.0dc2fa6b.js";import{_ as B}from"./index.5e4942ca.js";const C=$(" \u641C\u7D22 "),F={setup(N){const r=Object.keys(A);return(V,q)=>{const p=y,m=o("el-icon-edit"),_=o("el-icon"),d=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),a=j,x=g,h=o("el-tooltip");return s(),c("div",null,[e(k),e(p,{title:"\u56FE\u6807"}),e(a,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(b)},{default:n(()=>[C]),_:1},8,["icon"])]),_:1}),e(a,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(s(!0),c(E,null,I(t(r),(l,v)=>(s(),c("div",{key:v,class:"list-icon"},[e(h,{class:"item",effect:"dark",content:t(i)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(x,{name:t(i)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var G=B(F,[["__scopeId","data-v-58969013"]]);export{G as default};
