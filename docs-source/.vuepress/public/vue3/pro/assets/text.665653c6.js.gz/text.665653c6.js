
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i}from"./index.7acc1829.js";import{_ as l}from"./index.f0514fa3.js";import{l as u}from"./index.4e39c82e.js";import{B as d,l as p,F as t,D as n,o as m,m as f,Y as x,k as g,$ as a}from"./vendor.db0e6471.js";const h=a("\u5207\u6362"),B=a("\u6E05\u7A7A"),T={setup(k){const e=u();function s(){e.setText(e.text=="\u70ED\u95E8"?"\u4FC3\u9500":"\u70ED\u95E8")}function c(){e.setText()}return(b,j)=>{const _=l,o=d("el-button"),r=i;return m(),p("div",null,[t(_,{title:"\u6587\u5B57\u6807\u8BB0",content:"\u642D\u914D Pinia \u53EF\u5B9E\u73B0\u52A8\u6001\u8BBE\u7F6E\u3002\u8BF7\u63A7\u5236\u6587\u5B57\u5C55\u793A\u957F\u5EA6\uFF0C\u907F\u514D\u5BFC\u822A\u6807\u8BB0\u8986\u76D6\u5BFC\u822A\u6807\u9898"}),t(r,null,{default:n(()=>[f("div",null,"\u5F53\u524D badge \u503C\uFF1A'"+x(g(e).text)+"'",1),t(o,{onClick:s},{default:n(()=>[h]),_:1}),t(o,{onClick:c},{default:n(()=>[B]),_:1})]),_:1})])}}};export{T as default};
