
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{o as l,n as e,c as n}from"./index.2c18650f.js";import u from"./index.d83277f9.js";import{g as i,r as a,q as s,y as d,l as t}from"./vendor.9da56f98.js";var r="_example-icon_uueil_6",o="_test1_uueil_10",v="_a_uueil_13",c="_test2_uueil_19",m=i({name:"JsxExample",render(){const i=a(["sidebar-jsx","sidebar-element"]).value.map((l=>s(n,{name:l,class:r},null)));let m=a(0);const _=s("p",null,[d("这也是"),s("i",null,[d("一段")]),s("b",null,[d("HTML")]),d("代码")]);return s("div",null,[s(l,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),s(e,null,{default:()=>[s("p",null,[d("这是两个 Svg Icon 图标")]),i,s(t("el-divider"),null,null),s("div",{class:o},[s("div",{class:v},null)]),s("div",{class:c},[s("div",{class:v},null)]),s(t("el-divider"),null,null),s(t("el-button"),{onClick:()=>function(l=1){m.value+=l}(10)},{default:()=>[d("点我："),m.value]}),s("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),_,s(t("el-divider"),null,null),s(u,null,null)]})])}});export{m as default};
