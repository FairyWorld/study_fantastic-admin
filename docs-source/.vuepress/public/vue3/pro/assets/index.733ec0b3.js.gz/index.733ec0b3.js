
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as o,b as s,n as a,o as t}from"./index.2c18650f.js";import{h as n,q as l,w as e,l as r,o as c,i as d,y as i}from"./vendor.9da56f98.js";const u={methods:{close(){this.$tabbar.close("/dashboard")}}},f=d("p",null,"访问侧边栏导航里的任意路由，都会在标签栏里自动创建一个标签。",-1),p=d("p",null,"除了在标签栏里操作关闭标签，你也可以使用全局方法关闭当前页面的标签。但如果当前只有一个标签时，则无法关闭。",-1),b=i("关闭当前标签页");"function"==typeof s&&s(u);var m=o(u,[["render",function(o,s,d,i,u,m){const h=t,v=r("el-button"),_=a;return c(),n("div",null,[l(h,{title:"标签栏",content:"功能类似于浏览器的标签栏，支持右键操作"}),l(_,null,{default:e((()=>[f,p,l(v,{onClick:m.close},{default:e((()=>[b])),_:1},8,["onClick"])])),_:1})])}]]);export{m as default};
