
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{d as l,r as e,b as n,z as u,ad as a,ac as i,n as s,B as d}from"./index.87af0725.js";import t from"./index.041aa732.js";var r="_example-icon_uueil_6",v="_test1_uueil_10",c="_a_uueil_13",o="_test2_uueil_19",_=l({name:"JsxExample",render(){const l=e(["sidebar-jsx","sidebar-element"]).value.map((l=>n(d,{name:l,class:r},null)));let _=e(0);const m=n("p",null,[u("这也是"),n("i",null,[u("一段")]),n("b",null,[u("HTML")]),u("代码")]);return n("div",null,[n(a,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),n(i,null,{default:()=>[n("p",null,[u("这是两个 Svg Icon 图标")]),l,n(s("el-divider"),null,null),n("div",{class:v},[n("div",{class:c},null)]),n("div",{class:o},[n("div",{class:c},null)]),n(s("el-divider"),null,null),n(s("el-button"),{onClick:()=>function(l=1){_.value+=l}(10)},{default:()=>[u("点我："),_.value]}),n("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),m,n(s("el-divider"),null,null),n(t,null,null)]})])}});export{_ as default};
