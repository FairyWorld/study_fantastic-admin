
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as y}from"./index.d8082f89.js";import{_ as k}from"./index.a91da01e.js";import{_ as x}from"./index.454d22a3.js";import E from"./alert.8107a9bd.js";import{l as c,F as e,A as o,D as n,o as l,k as t,aq as I,a3 as b,a2 as $,$ as A,R as B}from"./vendor.d1c84aa2.js";import{h as r}from"./index.0dc2fa6b.js";import{_ as C}from"./index.8f12b84b.js";const F=A(" \u641C\u7D22 "),N={setup(V){const i=Object.keys(B);return(j,q)=>{const p=x,m=n("el-icon-edit"),_=n("el-icon"),u=n("el-icon-share"),d=n("el-icon-delete"),f=n("el-button"),a=k,h=y,v=n("el-tooltip");return l(),c("div",null,[e(E),e(p,{title:"\u56FE\u6807"}),e(a,{class:"demo"},{default:o(()=>[e(_,null,{default:o(()=>[e(m)]),_:1}),e(_,null,{default:o(()=>[e(u)]),_:1}),e(_,null,{default:o(()=>[e(d)]),_:1}),e(f,{type:"primary",icon:t(I)},{default:o(()=>[F]),_:1},8,["icon"])]),_:1}),e(a,{title:"\u56FE\u6807\u96C6\u5408"},{default:o(()=>[(l(!0),c(b,null,$(t(i),(s,g)=>(l(),c("div",{key:g,class:"list-icon"},[e(v,{class:"item",effect:"dark",content:t(r)(`ElIcon${s}`),placement:"top"},{default:o(()=>[e(h,{name:t(r)(`ElIcon${s}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var G=C(N,[["__scopeId","data-v-33929a0d"]]);export{G as default};
