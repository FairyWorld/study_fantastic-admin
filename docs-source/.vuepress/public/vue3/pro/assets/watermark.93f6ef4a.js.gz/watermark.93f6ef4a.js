
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{u as d,m as f,n as g}from"./index.e5f7e690.js";import{z as b,h as k,q as e,w as o,l as r,o as h,u as v,ak as x,y as _}from"./vendor.ee7254f0.js";var u={};const V=_("\u5F00\u542F"),W=_("\u5173\u95ED"),y={setup(S){const a=d(),n=b({get:function(){return a.app.enableWatermark},set:function(l){a.$patch(t=>{t.app.enableWatermark=l})}});return(l,t)=>{const c=g,s=r("el-radio-button"),p=r("el-radio-group"),i=f;return h(),k("div",null,[e(c,{title:"\u9875\u9762\u6C34\u5370",content:"\u5728\u67D0\u4E9B\u573A\u666F\u4E0B\uFF0C\u4E0D\u5E0C\u671B\u7528\u6237\u5C06\u7CFB\u7EDF\u91CC\u7684\u4FE1\u606F\u968F\u610F\u622A\u56FE\u5E76\u8F6C\u53D1\uFF0C\u8FD9\u65F6\u53EF\u5F00\u542F\u9875\u9762\u6C34\u5370\uFF0C\u4EE5\u51CF\u5C11\u8FD9\u79CD\u60C5\u51B5\u53D1\u751F"}),e(i,{title:"\u53EF\u5728 src\\layout\\components\\Watermark\\index.vue \u6587\u4EF6\u91CC\u5B9A\u5236\u6C34\u5370\u6587\u6848\u5185\u5BB9"},{default:o(()=>[e(p,{modelValue:v(n),"onUpdate:modelValue":t[0]||(t[0]=m=>x(n)?n.value=m:null)},{default:o(()=>[e(s,{label:!0},{default:o(()=>[V]),_:1}),e(s,{label:!1},{default:o(()=>[W]),_:1})]),_:1},8,["modelValue"])]),_:1})])}}};typeof u=="function"&&u(y);export{y as default};
