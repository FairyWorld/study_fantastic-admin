
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as d}from"./index.a91da01e.js";import{_ as i}from"./index.454d22a3.js";import a from"./alert.8107a9bd.js";import{_}from"./index.8f12b84b.js";import{l as V,F as e,A as u,D as s,o as f}from"./vendor.d1c84aa2.js";const c={components:{Alert:a},data(){return{num:1,num2:1,num3:5,num4:1,num5:1}}};function x(b,l,g,U,n,A){const p=s("Alert"),r=i,m=s("el-input-number"),t=d;return f(),V("div",null,[e(p),e(r,{title:"\u8BA1\u6570\u5668"}),e(t,{title:"\u57FA\u7840\u7528\u6CD5",class:"demo"},{default:u(()=>[e(m,{modelValue:n.num,"onUpdate:modelValue":l[0]||(l[0]=o=>n.num=o),min:1,max:10,label:"\u63CF\u8FF0\u6587\u5B57"},null,8,["modelValue"])]),_:1}),e(t,{title:"\u7981\u7528\u72B6\u6001",class:"demo"},{default:u(()=>[e(m,{modelValue:n.num2,"onUpdate:modelValue":l[1]||(l[1]=o=>n.num2=o),disabled:!0},null,8,["modelValue"])]),_:1}),e(t,{title:"\u6B65\u6570",class:"demo"},{default:u(()=>[e(m,{modelValue:n.num3,"onUpdate:modelValue":l[2]||(l[2]=o=>n.num3=o),step:2},null,8,["modelValue"])]),_:1}),e(t,{title:"\u7CBE\u5EA6",class:"demo"},{default:u(()=>[e(m,{modelValue:n.num4,"onUpdate:modelValue":l[3]||(l[3]=o=>n.num4=o),precision:2,step:.1,max:10},null,8,["modelValue","step"])]),_:1}),e(t,{title:"\u6309\u94AE\u4F4D\u7F6E",class:"demo"},{default:u(()=>[e(m,{modelValue:n.num5,"onUpdate:modelValue":l[4]||(l[4]=o=>n.num5=o),"controls-position":"right",min:1,max:10},null,8,["modelValue"])]),_:1})])}var D=_(c,[["render",x]]);export{D as default};
