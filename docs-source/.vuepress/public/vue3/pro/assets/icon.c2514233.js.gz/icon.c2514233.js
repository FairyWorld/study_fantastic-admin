
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as e,c as a,b as t,w as l,j as s,n,ac as o,q as c,g as i,ak as d,H as u,G as r,z as f,as as m,ad as p,B as _}from"./index.992324c5.js";import j from"./alert.9821d680.js";import{h as y}from"./index.0dc2fa6b.js";const b=f(" 搜索 "),k={setup(e){const s=Object.keys(m);return(e,f)=>{const m=p,k=n("el-icon-edit"),v=n("el-icon"),x=n("el-icon-share"),I=n("el-icon-delete"),h=n("el-button"),E=o,$=_,g=n("el-tooltip");return c(),a("div",null,[t(j),t(m,{title:"图标"}),t(E,{class:"demo"},{default:l((()=>[t(v,null,{default:l((()=>[t(k)])),_:1}),t(v,null,{default:l((()=>[t(x)])),_:1}),t(v,null,{default:l((()=>[t(I)])),_:1}),t(h,{type:"primary",icon:i(d)},{default:l((()=>[b])),_:1},8,["icon"])])),_:1}),t(E,{title:"图标集合"},{default:l((()=>[(c(!0),a(u,null,r(i(s),((e,s)=>(c(),a("div",{key:s,class:"list-icon"},[t(g,{class:"item",effect:"dark",content:i(y)(`ElIcon${e}`),placement:"top"},{default:l((()=>[t($,{name:i(y)(`ElIcon${e}`)},null,8,["name"])])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof s&&s(k);var v=e(k,[["__scopeId","data-v-cc12e516"]]);export{v as default};
