
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as x,m as b,n as E,b as I}from"./index.a1178b85.js";import C from"./alert.a0609b5a.js";import{h as c,q as e,w as n,l as o,o as l,u as t,aq as q,F as w,C as B,y as F,Z as N}from"./vendor.ee7254f0.js";import{h as i}from"./index.0dc2fa6b.js";var p={};const V=F(" \u641C\u7D22 "),r={setup($){const u=Object.keys(N);return(j,A)=>{const m=E,d=o("el-icon-edit"),_=o("el-icon"),f=o("el-icon-share"),h=o("el-icon-delete"),v=o("el-button"),s=b,y=I,g=o("el-tooltip");return l(),c("div",null,[e(C),e(m,{title:"\u56FE\u6807"}),e(s,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(f)]),_:1}),e(_,null,{default:n(()=>[e(h)]),_:1}),e(v,{type:"primary",icon:t(q)},{default:n(()=>[V]),_:1},8,["icon"])]),_:1}),e(s,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(l(!0),c(w,null,B(t(u),(a,k)=>(l(),c("div",{key:k,class:"list-icon"},[e(g,{class:"item",effect:"dark",content:t(i)(`ElIcon${a}`),placement:"top"},{default:n(()=>[e(y,{name:t(i)(`ElIcon${a}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};typeof p=="function"&&p(r);var z=x(r,[["__scopeId","data-v-cc12e516"]]);export{z as default};
