
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as g}from"./index.36bfd5ad.js";import{_ as j}from"./index.13c1af28.js";import{_ as y}from"./index.a1ea47af.js";import b from"./alert.8da0b9a6.js";import{B as o,l as c,F as e,D as n,o as a,k as t,aq as k,a3 as E,a2 as I,$ as B,R as $}from"./vendor.e498156c.js";import{h as i}from"./index.0dc2fa6b.js";import{_ as C}from"./index.85d61d52.js";const F=B(" \u641C\u7D22 "),N={setup(V){const r=Object.keys($);return(q,w)=>{const p=y,d=o("el-icon-edit"),_=o("el-icon"),m=o("el-icon-share"),u=o("el-icon-delete"),f=o("el-button"),s=j,x=g,h=o("el-tooltip");return a(),c("div",null,[e(b),e(p,{title:"\u56FE\u6807"}),e(s,{class:"demo"},{default:n(()=>[e(_,null,{default:n(()=>[e(d)]),_:1}),e(_,null,{default:n(()=>[e(m)]),_:1}),e(_,null,{default:n(()=>[e(u)]),_:1}),e(f,{type:"primary",icon:t(k)},{default:n(()=>[F]),_:1},8,["icon"])]),_:1}),e(s,{title:"\u56FE\u6807\u96C6\u5408"},{default:n(()=>[(a(!0),c(E,null,I(t(r),(l,v)=>(a(),c("div",{key:v,class:"list-icon"},[e(h,{class:"item",effect:"dark",content:t(i)(`ElIcon${l}`),placement:"top"},{default:n(()=>[e(x,{name:t(i)(`ElIcon${l}`)},null,8,["name"])]),_:2},1032,["content"])]))),128))]),_:1})])}}};var G=C(N,[["__scopeId","data-v-58969013"]]);export{G as default};
