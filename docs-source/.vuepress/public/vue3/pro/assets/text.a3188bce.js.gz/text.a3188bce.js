
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as i}from"./index.1bd2d262.js";import{_ as l}from"./index.c5ec1ecf.js";import{n as u}from"./index.677bf551.js";import{l as d,F as t,A as n,D as p,o as m,m as f,Y as x,k as g,$ as s}from"./vendor.7ef8ea63.js";const h=s("\u5207\u6362"),b=s("\u6E05\u7A7A"),T={setup(k){const e=u();function a(){e.setText(e.text=="\u70ED\u95E8"?"\u4FC3\u9500":"\u70ED\u95E8")}function c(){e.setText()}return(B,j)=>{const _=l,o=p("el-button"),r=i;return m(),d("div",null,[t(_,{title:"\u6587\u5B57\u6807\u8BB0",content:"\u642D\u914D Pinia \u53EF\u5B9E\u73B0\u52A8\u6001\u8BBE\u7F6E\u3002\u8BF7\u63A7\u5236\u6587\u5B57\u5C55\u793A\u957F\u5EA6\uFF0C\u907F\u514D\u5BFC\u822A\u6807\u8BB0\u8986\u76D6\u5BFC\u822A\u6807\u9898"}),t(r,null,{default:n(()=>[f("div",null,"\u5F53\u524D badge \u503C\uFF1A'"+x(g(e).text)+"'",1),t(o,{onClick:a},{default:n(()=>[h]),_:1}),t(o,{onClick:c},{default:n(()=>[b]),_:1})]),_:1})])}}};export{T as default};
